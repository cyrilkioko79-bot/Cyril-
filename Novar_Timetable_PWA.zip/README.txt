NOVAR TIMETABLE — INSTALLABLE WEB APP

Files:
- index.html: Novar Timetable app
- manifest.webmanifest: app name, icon and install settings
- sw.js: offline caching service worker
- icons/: app icons

HOW TO HOST FREE WITH GITHUB PAGES (Android or computer):
1. Sign in or create a GitHub account at https://github.com
2. Create a NEW PUBLIC repository, for example: novar-timetable
3. Choose Add file > Upload files (or the + menu on mobile).
4. Upload the contents of this folder: index.html, manifest.webmanifest, sw.js, and the icons folder. Keep the same folder structure.
5. Commit/save the files.
6. Open repository Settings > Pages.
7. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
8. Wait a minute or two. GitHub will show a site address similar to https://YOUR-USERNAME.github.io/novar-timetable/ .
9. Open that HTTPS address in Chrome on Android. Use Chrome's ⋮ menu > Install app or Add to Home screen.

IMPORTANT:
- Keep the repository public if using GitHub Free Pages.
- Anyone who knows the public site address can visit the app. Do not enter private or sensitive information.
- App data is stored locally in the browser on your phone; it does not automatically sync to other devices. Export backups regularly.
- This is a PWA, not a Play Store APK. Publishing to Google Play is a separate process.
